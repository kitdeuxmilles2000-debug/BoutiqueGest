"""Blueprints de l'application."""
